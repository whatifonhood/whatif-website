WHAT $IF — BRAND KIT
====================

Everything you need to make $IF community content. Use it for $IF: posts,
memes, stickers, videos. Not for another token, project or product, and
nothing here implies endorsement — see NOTICE.txt in this kit.

WHAT IS IN HERE
  01-token-logo        The coin. Use for the token: DEX listings, wallets,
                       token lists, price trackers. Always the full coin
                       WITH its rim — the rim is what makes it read as currency.
  02-avatar            The character, cropped so it fills a circular crop.
                       Use for profile pictures.
  03-wordmark          The name, as true vector. Use for headers, overlays,
                       merch and partner placements. The two four-point stars
                       off the F are part of the mark — keep them.
  04-favicon           Browser and app icons.
  05-character         The IF Man reference sheet and the prompt kit. Attach the
                       sheet as an image reference in any AI tool and pair it
                       with the prompt blocks. Generate from the reference,
                       never from memory.
  06-banners           Ready-made social banners.
  07-character-cutouts Transparent poses for memes.

THE PALETTE
  Void Black    #080B07   background
  Bright Lime   #8FCE02   primary
  Mid Lime      #86B50B   support
  Deep Green    #305B05   shadow
  Pale Lime     #C4DC43   highlight
  Galaxy Gold   #E4D98E   accent, sparingly

THE TYPE
  Archivo Black Italic 900, uppercase, tight tracking — headlines and wordmark.
  JetBrains Mono — anything exact or copyable. Never set a contract address in
  a display face.

THE CHARACTER — ALWAYS
  Bald, clean-shaven, lean-athletic, long neck and limbs.
  Flat acid-lime skin, thick black contour, horizontal engraving on skull/neck.
  Black space, green nebulae, gold-white galaxy cores, four-point stars.
  Calm and restrained. He wonders. He does not mug.

THE CHARACTER — NEVER
  Hair, beard, stubble or hair-like eyebrows.
  Suits, armour, jewellery, footwear, capes.
  Glossy 3D or photoreal skin. The coin's metallic render is the one exception.
  The Robinhood feather logo — write "on Robinhood Chain" instead.

VOICE
  Curious, cosmic, slightly deadpan. The question is the brand: leave it open,
  do not answer it.

THE ONLY OFFICIAL SITE IS whatifonhood.com
Contract: 0x232CDFc415D10b673845D83Dc02ba2eaBe7e30d1
Always verify the contract address against whatifonhood.com and @WhatIFonHOOD.

$IF is a meme coin with no intrinsic value. Not financial advice.
