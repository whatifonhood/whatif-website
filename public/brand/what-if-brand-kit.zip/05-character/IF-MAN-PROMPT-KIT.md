# IF Man — AI Generator Prompt Kit

Use this kit with any AI image generator. Attach `if-man-reference-sheet-4k.png` (primary:
turnaround + head front + hand studies) as the image reference wherever the tool supports
needs the head profile or rear head construction (Midjourney `--sref`/image prompt, nano
banana / Gemini image references, SDXL IP-Adapter, DALL-E vision reference, Flux Redux);
where it doesn't, the text blocks below carry the canon alone.


## Core character block (paste into any prompt)

> IF Man: an adult male cosmic humanoid, completely bald and clean-shaven, godlike
> heroically idealized face like a classical statue of a demigod — powerful brow ridge,
> deep-set calm eyes with small dark engraved irises, pronounced angular cheekbones,
> straight strong nose, chiseled square jaw and firm level mouth, stoic and serene,
> tall lean-athletic build about 7.75 heads tall with broad shoulders, long neck, long
> limbs and a narrow waist, solid flat acid-chartreuse green skin (#8FCE02) with mid-tone
> #86B50B shading, deep green #305B05 shadows and pale #C4DC43 highlights, thick black
> silhouette contour outline, hand-drawn graphic-novel engraving style with dense
> horizontal contour hatching wrapping the skull, neck, trapezius, shoulders and back,
> cross-hatching on the shoulder blades and underside planes, flat comic ink rendering,
> restrained calm expression, unclothed stylized non-explicit cosmic anatomy with no
> clothing or accessories

## Scene language (optional, for environment shots)

> deep black space, acid-green nebulae, a luminous green-and-gold spiral galaxy, small
> green planets, four-point stars, dark rocky alien planet surface, soft lime aura around
> the figure

## Negative prompt / exclusions (paste wherever the tool takes negatives)

> beard, facial hair, stubble, hair, eyebrows that look like hair, human skin texture,
> bodysuit, armor, boots, gloves, cape, belt, jewelry, superhero costume, glossy 3D skin,
> veins, bodybuilder exaggeration, photoreal human portrait, babyface, extra limbs,
> malformed hands, extra fingers, text, watermark, logo

## Tool notes

- **Midjourney**: append `--no beard, hair, clothing, gloss, text` and use the sheet as an
  image prompt or `--sref`. Style tends photoreal — add "flat comic ink, engraving
  hatching" early in the prompt.
- **SDXL / ComfyUI**: use the negative block verbatim; IP-Adapter weight ~0.6–0.8 with the
  sheet; CFG on the higher side to hold the flat color.
- **nano banana / Gemini**: attach the sheet (and optionally the coin) as image
  references; state "identical original character from the reference in every view".
- **DALL-E / GPT-image**: no negative field — fold the exclusions into the prompt as
  "no beard, no clothing, no gloss…".

## Hard rules (never override)

1. Bald + clean-shaven, always. No hair anywhere.
2. Flat comic engraving, never glossy/photoreal — the metallic coin render is the one
   sanctioned exception, and only for the coin itself.
3. Palette stays lime-on-black; gold only for galaxy cores.
4. He wonders — never rages, never mugs. Restrained expression only.
5. Generate FROM the reference sheet, never from memory.

## Face drift — the block that actually holds (added 2026-09-01)

Seth flagged that generations "weren't the real IF man". The generic prompt kept drifting to a
soft, jowly, middle-aged bald man. The reference sheet's face is the opposite. Paste these
specifics into every prompt, not just "godlike idealised face":

> completely bald and clean-shaven, no hair anywhere, but with HEAVY STRAIGHT DARK EYEBROWS.
> Narrow, deep-set, hard eyes with a flat level stare. High sharp cheekbones, strong straight
> nose, WIDE SQUARE MASCULINE JAW with a defined chin, thin firm mouth. Thick muscular neck,
> broad shoulders and trapezius. A lean, athletic, heroically proportioned adult man in his
> prime — NOT soft, NOT jowly, NOT middle-aged, NOT chubby.

The two negations at the end do most of the work. Best match so far: `poll-sees-100x.png`.

## Real meme assets: composite, never regenerate

Seth, twice: "use the actual meme" / "you didn't use the real cashcat". Asking the model to
reproduce a real meme character from a reference **always drifts** — CashCat came back as a
grey tabby, then a ginger cat, never the actual crying cat.

The reliable method is to generate the scene with a deliberate EMPTY SPACE for the subject
("no cat, the left cushion must be empty"), then composite the real cut-out in with
ImageMagick:

```
# cut out (white bg → transparent), corners flood-filled
magick cashcat-logo.jpg -resize 1200x1200 -fuzz 12% -fill none \
  -draw "alpha 1,1 floodfill" -draw "alpha 1198,1 floodfill" \
  -draw "alpha 1,1198 floodfill" -draw "alpha 1198,1198 floodfill" -trim +repage cat-cut.png
# match scene lighting, then place
magick cat-cut.png -resize x700 -modulate 112,105,100 cat-b.png
magick cat-b.png \( +clone -fill '#d24a3a' -colorize 100 \) -compose Multiply -composite cat-t.png
magick cat-b.png cat-t.png -compose blend -define compose:args=32 -composite cat-lit.png
magick scene.png cat-lit.png -geometry +360+620 -composite out.png
```

Cutout kept at `what-if-meme/assets/cashcat/cashcat-cutout.png`. Tint blend ~32% matched a
red-lit room; raise or lower to match the scene's key light.

## Style-heavy pieces: technique yes, anatomy never (added 2026-09-02)

Seth caught IF Man going off-model in the ukiyo-e Great Wave piece — the woodblock style
absorbed him: rounder face, softer jaw, lost brow, and it added a brown waist wrap. Any strong
external art style (ukiyo-e, medieval, Egyptian, cave painting, Soviet poster) will try to
redraw his face in that idiom.

Paste this into every style-heavy prompt:

> STYLE APPLIES TO TECHNIQUE ONLY, NEVER TO THE CHARACTER'S ANATOMY. However this piece is
> rendered, IF MAN's facial structure and proportions stay exactly as specified — completely
> bald, HEAVY STRAIGHT DARK EYEBROWS, narrow deep-set eyes, HIGH SHARP CHEEKBONES, strong
> straight nose, WIDE SQUARE HEAVY MASCULINE JAW, thin firm level mouth, tall heroic classical
> physique. Do NOT simplify, soften, round or stylise his face to suit the medium, and do not
> add clothing the brief did not ask for.
